ALT Keyboard - Android Project ZIP

App Name: ALT Keyboard
Package: com.altproduction.altkeyboard

Features included:
- Android InputMethodService keyboard
- Fix English button
- English → Hinglish
- Hindi → Hinglish
- Hinglish → English
- Clipboard/typed history auto clears after 24 hours
- Long press quick action
- Yellow About page
- Dev - Ashu
- The Owner and Founder of ALT Production
- Typing key click sound using Android AudioManager

Placeholders added for future upgrade:
- Custom keyboard photo/background picker
- Multiple mechanical keyboard sounds
- Real AI translation API integration

How to build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build APK.
4. Install APK.
5. Open app → Enable ALT Keyboard → Choose ALT Keyboard.

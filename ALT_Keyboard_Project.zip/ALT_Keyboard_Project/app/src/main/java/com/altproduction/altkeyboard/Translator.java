package com.altproduction.altkeyboard;

public class Translator {
    public static String convert(String text, String mode) {
        if (text == null) return "";
        String t = text.trim();

        switch(mode) {
            case "fix": return fixEnglish(t);
            case "en_hi": return englishToHinglish(t);
            case "hi_hing": return hindiToHinglish(t);
            case "hing_en": return hinglishToEnglish(t);
            default: return t;
        }
    }

    static String fixEnglish(String t) {
        t = t.replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        t = t.substring(0,1).toUpperCase() + t.substring(1);
        if (!t.matches(".*[.!?]$")) t += ".";
        return t;
    }

    static String englishToHinglish(String t) {
        String s = t.toLowerCase();
        s = s.replace("okay, i will pay attention to that. thank you.", "Okay, main us baat ka dhyan rakhunga. Thank you.");
        s = s.replace("where are you", "tum kahan ho");
        s = s.replace("what are you doing", "tum kya kar rahe ho");
        s = s.replace("tell me", "batao");
        s = s.replace("send", "bhejo");
        return capitalize(s);
    }

    static String hindiToHinglish(String t) {
        return t.replace("नमस्ते", "Namaste")
                .replace("क्या", "kya")
                .replace("तुम", "tum")
                .replace("कहाँ", "kahan")
                .replace("हो", "ho")
                .replace("बताओ", "batao")
                .replace("धन्यवाद", "thank you");
    }

    static String hinglishToEnglish(String t) {
        String s = t.toLowerCase();
        s = s.replace("main", "I");
        s = s.replace("tum", "you");
        s = s.replace("kya", "what");
        s = s.replace("kahan", "where");
        s = s.replace("batao", "tell me");
        s = s.replace("dhyan rakhunga", "will pay attention");
        return capitalize(s);
    }

    static String capitalize(String s) {
        if (s.length() == 0) return s;
        return s.substring(0,1).toUpperCase() + s.substring(1);
    }
}

package com.altproduction.altkeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.*;
import android.content.*;
import android.media.AudioManager;
import android.view.Gravity;
import java.util.*;

public class AltKeyboardService extends InputMethodService {
    LinearLayout root;
    String typedBuffer = "";
    SharedPreferences prefs;

    @Override public View onCreateInputView() {
        prefs = getSharedPreferences("alt_keyboard", MODE_PRIVATE);
        clearClipboardAfter24h();

        root = (LinearLayout) getLayoutInflater().inflate(getResources().getIdentifier("keyboard_view", "layout", getPackageName()), null);

        setupActionButtons();
        setupRows();

        return root;
    }

    void setupActionButtons() {
        root.findViewById(getResources().getIdentifier("fixEnglish", "id", getPackageName())).setOnClickListener(v -> replaceLastText("fix"));
        root.findViewById(getResources().getIdentifier("enHinglish", "id", getPackageName())).setOnClickListener(v -> replaceLastText("en_hi"));
        root.findViewById(getResources().getIdentifier("hiHinglish", "id", getPackageName())).setOnClickListener(v -> replaceLastText("hi_hing"));
        root.findViewById(getResources().getIdentifier("hinglishEnglish", "id", getPackageName())).setOnClickListener(v -> replaceLastText("hing_en"));
        root.findViewById(getResources().getIdentifier("clipboardBtn", "id", getPackageName())).setOnClickListener(v -> showClipboard());
    }

    void setupRows() {
        addKeys((LinearLayout)root.findViewById(getResources().getIdentifier("row1", "id", getPackageName())), new String[]{"q","w","e","r","t","y","u","i","o","p"});
        addKeys((LinearLayout)root.findViewById(getResources().getIdentifier("row2", "id", getPackageName())), new String[]{"a","s","d","f","g","h","j","k","l"});
        addKeys((LinearLayout)root.findViewById(getResources().getIdentifier("row3", "id", getPackageName())), new String[]{"⇧","z","x","c","v","b","n","m","⌫"});
        addKeys((LinearLayout)root.findViewById(getResources().getIdentifier("row4", "id", getPackageName())), new String[]{"123",",","SPACE",".","ENTER"});
    }

    void addKeys(LinearLayout row, String[] keys) {
        for (String k: keys) {
            TextView key = new TextView(this);
            key.setText(k);
            key.setGravity(Gravity.CENTER);
            key.setTextColor(0xffffffff);
            key.setTextSize(k.equals("SPACE") ? 14 : 18);
            key.setBackgroundResource(getResources().getIdentifier("key_bg", "drawable", getPackageName()));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, k.equals("SPACE") ? 4 : 1);
            lp.setMargins(4,4,4,4);
            row.addView(key, lp);

            key.setOnClickListener(v -> pressKey(k));
            key.setOnLongClickListener(v -> {
                if(k.equals("SPACE")) showAboutToast();
                else replaceLastText("fix");
                return true;
            });
        }
    }

    void pressKey(String k) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        playTypingSound();

        if (k.equals("⌫")) {
            ic.deleteSurroundingText(1,0);
            if (typedBuffer.length() > 0) typedBuffer = typedBuffer.substring(0, typedBuffer.length()-1);
            return;
        }
        if (k.equals("SPACE")) { ic.commitText(" ",1); typedBuffer += " "; saveClipBuffer(); return; }
        if (k.equals("ENTER")) { ic.commitText("\n",1); typedBuffer += "\n"; saveClipBuffer(); return; }
        if (k.equals("123") || k.equals("⇧")) return;

        ic.commitText(k,1);
        typedBuffer += k;
        saveClipBuffer();
    }

    void replaceLastText(String mode) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(700, 0);
        if (before == null || before.length() == 0) return;

        String original = before.toString();
        String converted = Translator.convert(original, mode);
        ic.deleteSurroundingText(original.length(), 0);
        ic.commitText(converted, 1);
        typedBuffer = converted;
        saveClipBuffer();
    }

    void saveClipBuffer() {
        prefs.edit().putString("last_text", typedBuffer).putLong("last_saved", System.currentTimeMillis()).apply();
    }

    void clearClipboardAfter24h() {
        long last = prefs.getLong("last_saved", 0);
        if (last > 0 && System.currentTimeMillis() - last > 24L*60L*60L*1000L) {
            prefs.edit().clear().apply();
            typedBuffer = "";
        } else {
            typedBuffer = prefs.getString("last_text", "");
        }
    }

    void showClipboard() {
        String saved = prefs.getString("last_text", "");
        Toast.makeText(this, saved.length() == 0 ? "Clipboard empty" : saved, Toast.LENGTH_LONG).show();
    }

    void showAboutToast() {
        Toast.makeText(this, "ALT Keyboard from ALT Production • Dev - Ashu", Toast.LENGTH_LONG).show();
    }

    void playTypingSound() {
        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        if (am != null) am.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.7f);
    }
}

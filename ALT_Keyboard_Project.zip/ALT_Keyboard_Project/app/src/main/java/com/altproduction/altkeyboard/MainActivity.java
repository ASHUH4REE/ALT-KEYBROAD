package com.altproduction.altkeyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.graphics.Color;
import android.view.View;
import android.content.Context;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(34, 44, 34, 34);
        root.setBackgroundColor(Color.rgb(247, 201, 72));

        TextView title = new TextView(this);
        title.setText("ALT Keyboard");
        title.setTextSize(34);
        title.setTextColor(Color.rgb(16,20,38));
        title.setTypeface(null, 1);
        root.addView(title);

        TextView about = new TextView(this);
        about.setText("\nAbout ALT Keyboard\n\nALT Keyboard is from ALT Production.\n\nDev - Ashu\nThe Owner and Founder of ALT Production.\n\nFeatures:\n• Fix English\n• Hindi → Hinglish\n• English → Hinglish\n• Hinglish → English\n• Clipboard history auto clear after 24 hours\n• Typing sound support placeholder\n• Keyboard background/photo feature placeholder\n");
        about.setTextSize(17);
        about.setTextColor(Color.rgb(16,20,38));
        root.addView(about);

        Button enable = new Button(this);
        enable.setText("Enable ALT Keyboard");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        Button choose = new Button(this);
        choose.setText("Choose ALT Keyboard");
        choose.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showInputMethodPicker();
        });
        root.addView(choose);

        TextView note = new TextView(this);
        note.setText("\nNote: AI-level translation needs an API later. This project includes offline basic conversion logic.");
        note.setTextColor(Color.rgb(16,20,38));
        root.addView(note);

        setContentView(root);
    }
}
